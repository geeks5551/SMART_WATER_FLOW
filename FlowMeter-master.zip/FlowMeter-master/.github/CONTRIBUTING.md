## Contributing to the FlowMeter library

All pull requests are welcome.
Please follow the pull request template.

If you have a question or suggestion, feel free to open an issue on Github.
Please follow the issue template.